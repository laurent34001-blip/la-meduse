Pack de variantes du logo Trottipièces

Couleurs de marque :
- Bleu principal : #007BFF
- Vert secondaire : #10B981

Dossiers :
01_concepts_initiaux : propositions de logo générées au départ.
02_fond_blanc_couleur : versions couleur sur fond blanc.
03_fonds_colores_unis_logo_blanc : anciennes versions blanc sur fonds unis bleu/vert.
04_fond_degrade_logo_blanc : versions demandées avec fond en dégradé bleu/vert.
05_fond_transparent_png : versions PNG à fond transparent.
06_aperçus_transparence_checkerboard : aperçus visuels sur damier, fournis en complément.
